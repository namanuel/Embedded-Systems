

#ifndef _TIMER_H_
void timer_init();


#endif
